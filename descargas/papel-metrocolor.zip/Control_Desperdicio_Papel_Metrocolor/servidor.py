"""Control de Desperdicio de Papel · Metrocolor
Servidor local en Python (sin dependencias externas) con base de datos SQLite.

Uso:
    python servidor.py              # abre en el puerto 8080
    python servidor.py --puerto 9000

Desde cualquier celular o computadora de la misma red abre:
    http://<IP de esta PC>:8080
La IP se muestra al arrancar. Los datos viven en datos/papel.db y se respaldan
automáticamente en datos/respaldos/ (uno por día, se guardan los últimos 60).
"""
from __future__ import annotations

import argparse
import datetime as dt
import getpass
import hashlib
import hmac
import os
import json
import mimetypes
import shutil
import socket
import sqlite3
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
RAIZ = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
WEB = BASE / "web"
DATOS = RAIZ / "datos"
DB_PATH = DATOS / "papel.db"
RESPALDOS = DATOS / "respaldos"
INICIAL = DATOS / "inicial.cifrado"   # datos de arranque protegidos con clave
MAX_CUERPO = 25 * 1024 * 1024

_lock = threading.Lock()
_version = 0  # cambia en cada escritura; los navegadores lo consultan para refrescar


# ---------- datos de arranque cifrados (solo librería estándar) ----------
def _llaves(clave: str, sal: bytes) -> tuple[bytes, bytes]:
    k = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), sal, 200000, 64)
    return k[:32], k[32:]


def _flujo(llave: bytes, nonce: bytes, n: int) -> bytes:
    out = bytearray()
    i = 0
    while len(out) < n:
        out += hmac.new(llave, nonce + i.to_bytes(8, "big"), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def cifrar(datos: bytes, clave: str) -> bytes:
    sal, nonce = os.urandom(16), os.urandom(16)
    ke, km = _llaves(clave, sal)
    ct = bytes(a ^ b for a, b in zip(datos, _flujo(ke, nonce, len(datos))))
    return b"PAPEL1" + sal + nonce + ct + hmac.new(km, sal + nonce + ct, hashlib.sha256).digest()


def descifrar(blob: bytes, clave: str) -> bytes:
    if blob[:6] != b"PAPEL1":
        raise ValueError("archivo no reconocido")
    sal, nonce, ct, tag = blob[6:22], blob[22:38], blob[38:-32], blob[-32:]
    ke, km = _llaves(clave, sal)
    if not hmac.compare_digest(tag, hmac.new(km, sal + nonce + ct, hashlib.sha256).digest()):
        raise ValueError("clave incorrecta")
    return bytes(a ^ b for a, b in zip(ct, _flujo(ke, nonce, len(ct))))


def restaurar_inicial() -> None:
    """Primera vez en una PC: crea la base a partir de los datos cifrados."""
    if DB_PATH.exists() or not INICIAL.exists():
        return
    print("Primera vez en esta PC: se cargarán los datos de la planta.")
    blob = INICIAL.read_bytes()
    while True:
        clave = (os.environ.get("PAPEL_CLAVE") or getpass.getpass("Escribe la clave de datos y presiona Enter: ")).strip()
        try:
            DB_PATH.write_bytes(descifrar(blob, clave))
            print("Datos cargados correctamente.")
            return
        except ValueError:
            print("Clave incorrecta, intenta de nuevo.")
            if os.environ.get("PAPEL_CLAVE"):
                raise SystemExit(1)


def conectar() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    return con


def preparar_db() -> None:
    global _version
    DATOS.mkdir(parents=True, exist_ok=True)
    restaurar_inicial()
    with conectar() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS docs(
                         ruta TEXT PRIMARY KEY,      -- p. ej. auditorias/abc123
                         coleccion TEXT NOT NULL,    -- p. ej. auditorias
                         id TEXT NOT NULL,
                         datos TEXT NOT NULL,        -- JSON
                         actualizado TEXT NOT NULL)""")
        con.execute("CREATE INDEX IF NOT EXISTS ix_col ON docs(coleccion)")
        con.execute("""CREATE TABLE IF NOT EXISTS bitacora(
                         n INTEGER PRIMARY KEY AUTOINCREMENT,
                         fecha TEXT NOT NULL, accion TEXT NOT NULL,
                         ruta TEXT NOT NULL, ip TEXT)""")
        fila = con.execute("SELECT COALESCE(MAX(n),0) FROM bitacora").fetchone()
        _version = int(fila[0])


def ruta_valida(ruta: str) -> bool:
    partes = ruta.split("/")
    return bool(ruta) and len(partes) <= 15 and all(
        p and p not in (".", "..") and len(p) <= 200 for p in partes)


def dividir(ruta: str) -> tuple[str, str]:
    col, _, ident = ruta.rpartition("/")
    return col, ident


def respaldar(forzar: bool = False) -> Path | None:
    """Copia de seguridad diaria de la base (consistente aunque se esté usando)."""
    RESPALDOS.mkdir(parents=True, exist_ok=True)
    destino = RESPALDOS / f"papel_{dt.date.today():%Y-%m-%d}.db"
    if destino.exists() and not forzar:
        return None
    with conectar() as origen, sqlite3.connect(destino) as copia:
        origen.backup(copia)
    viejos = sorted(RESPALDOS.glob("papel_*.db"))[:-60]
    for v in viejos:
        v.unlink(missing_ok=True)
    return destino


def ciclo_respaldos() -> None:
    try:
        respaldar()
    except Exception as e:  # el respaldo nunca debe tirar el servidor
        print("Aviso: no se pudo respaldar:", e)
    t = threading.Timer(3600, ciclo_respaldos)
    t.daemon = True
    t.start()


class Manejador(BaseHTTPRequestHandler):
    server_version = "PapelMetrocolor/1.0"

    # ---------- utilidades ----------
    def _json(self, codigo: int, obj) -> None:
        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def _leer_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_CUERPO:
            raise ValueError("cuerpo vacío o demasiado grande")
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def _param(self, nombre: str) -> str:
        return (parse_qs(urlparse(self.path).query).get(nombre) or [""])[0]

    def log_message(self, fmt, *args):  # consola limpia: solo errores
        if args and str(args[1])[:1] in "45":
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _anotar(self, con, accion: str, ruta: str) -> None:
        global _version
        cur = con.execute("INSERT INTO bitacora(fecha,accion,ruta,ip) VALUES(?,?,?,?)",
                          (dt.datetime.now().isoformat(timespec="seconds"), accion, ruta,
                           self.client_address[0]))
        _version = cur.lastrowid

    # ---------- rutas ----------
    def do_GET(self):
        u = urlparse(self.path)
        try:
            if u.path == "/api/version":
                return self._json(200, {"v": _version})
            if u.path == "/api/doc":
                ruta = self._param("ruta")
                if not ruta_valida(ruta):
                    return self._json(400, {"error": "ruta inválida"})
                with conectar() as con:
                    f = con.execute("SELECT datos FROM docs WHERE ruta=?", (ruta,)).fetchone()
                return self._json(200, {"existe": bool(f), "datos": json.loads(f[0]) if f else None,
                                         "v": _version})
            if u.path == "/api/coleccion":
                col = self._param("ruta")
                if not ruta_valida(col):
                    return self._json(400, {"error": "ruta inválida"})
                with conectar() as con:
                    filas = con.execute("SELECT id, datos FROM docs WHERE coleccion=? ORDER BY id",
                                        (col,)).fetchall()
                return self._json(200, {"docs": [{"id": i, "datos": json.loads(d)} for i, d in filas],
                                         "v": _version})
            if u.path == "/api/respaldo":
                destino = respaldar(forzar=True)
                datos = destino.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f'attachment; filename="{destino.name}"')
                self.send_header("Content-Length", str(len(datos)))
                self.end_headers()
                self.wfile.write(datos)
                return
            return self._estatico(u.path)
        except Exception as e:
            return self._json(500, {"error": str(e)})

    def do_PUT(self):
        u = urlparse(self.path)
        if u.path != "/api/doc":
            return self._json(404, {"error": "no existe"})
        ruta = self._param("ruta")
        if not ruta_valida(ruta) or "/" not in ruta:
            return self._json(400, {"error": "ruta inválida"})
        try:
            datos = self._leer_json()
            if not isinstance(datos, dict):
                return self._json(400, {"error": "el documento debe ser un objeto"})
            col, ident = dividir(ruta)
            with _lock, conectar() as con:
                con.execute("""INSERT INTO docs(ruta,coleccion,id,datos,actualizado) VALUES(?,?,?,?,?)
                               ON CONFLICT(ruta) DO UPDATE SET datos=excluded.datos,
                               actualizado=excluded.actualizado""",
                            (ruta, col, ident, json.dumps(datos, ensure_ascii=False),
                             dt.datetime.now().isoformat(timespec="seconds")))
                self._anotar(con, "guardar", ruta)
            return self._json(200, {"ok": True, "v": _version})
        except Exception as e:
            return self._json(500, {"error": str(e)})

    def do_DELETE(self):
        u = urlparse(self.path)
        ruta = self._param("ruta")
        if u.path != "/api/doc" or not ruta_valida(ruta):
            return self._json(400, {"error": "ruta inválida"})
        with _lock, conectar() as con:
            con.execute("DELETE FROM docs WHERE ruta=?", (ruta,))
            self._anotar(con, "eliminar", ruta)
        return self._json(200, {"ok": True, "v": _version})

    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/api/hash":  # PBKDF2 para navegadores sin WebCrypto (http en la red local)
            try:
                d = self._leer_json()
                h = hashlib.pbkdf2_hmac("sha256", str(d["pass"]).encode("utf-8"),
                                        str(d["salt"]).encode("utf-8"), 100000, 32)
                return self._json(200, {"hash": h.hex()})
            except Exception as e:
                return self._json(400, {"error": str(e)})
        return self._json(404, {"error": "no existe"})

    def _estatico(self, ruta: str):
        nombre = "app.html" if ruta in ("/", "/index.html") else ruta.lstrip("/")
        archivo = (WEB / nombre).resolve()
        if WEB.resolve() not in archivo.parents or not archivo.is_file():
            return self._json(404, {"error": "no encontrado"})
        datos = archivo.read_bytes()
        tipo = mimetypes.guess_type(archivo.name)[0] or "application/octet-stream"
        if tipo.startswith("text/") or tipo.endswith("javascript"):
            tipo += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)


def ip_local() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def main() -> int:
    ap = argparse.ArgumentParser(description="Control de Desperdicio de Papel · Metrocolor")
    ap.add_argument("--puerto", type=int, default=8080)
    ap.add_argument("--sin-navegador", action="store_true", help="no abrir el navegador al iniciar")
    args = ap.parse_args()

    preparar_db()
    ciclo_respaldos()
    srv = ThreadingHTTPServer(("0.0.0.0", args.puerto), Manejador)
    ip = ip_local()
    print("=" * 62)
    print(" Control de Desperdicio de Papel · Metrocolor")
    print(f" En esta PC:            http://localhost:{args.puerto}")
    print(f" Celulares y otras PCs: http://{ip}:{args.puerto}")
    print(f" Base de datos:         {DB_PATH}")
    print(" Deja esta ventana abierta. Para detener: Ctrl+C")
    print("=" * 62)
    if not args.sin_navegador:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{args.puerto}")).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        respaldar(forzar=True)
        print("Servidor detenido. Respaldo guardado.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
