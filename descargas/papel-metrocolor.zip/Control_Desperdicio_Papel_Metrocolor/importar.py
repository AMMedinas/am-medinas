"""Importa a la base SQLite una carpeta de documentos JSON (<coleccion>/<id>.json).
Uso: python importar.py carpeta_exportada"""
import datetime as dt, json, sys
from pathlib import Path
import servidor

def main(carpeta: str) -> int:
    servidor.preparar_db()
    raiz = Path(carpeta); n = 0
    with servidor.conectar() as con:
        for f in sorted(raiz.rglob("*.json")):
            rel = f.relative_to(raiz).with_suffix("").as_posix()
            col, ident = servidor.dividir(rel)
            con.execute("INSERT OR REPLACE INTO docs(ruta,coleccion,id,datos,actualizado) VALUES(?,?,?,?,?)",
                        (rel, col, ident, json.dumps(json.loads(f.read_text("utf-8")), ensure_ascii=False),
                         dt.datetime.now().isoformat(timespec="seconds")))
            n += 1
        con.execute("INSERT INTO bitacora(fecha,accion,ruta,ip) VALUES(?,?,?,?)",
                    (dt.datetime.now().isoformat(timespec="seconds"), "importar", carpeta, "local"))
    print(f"Importados {n} documentos a {servidor.DB_PATH}")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "exportado"))
