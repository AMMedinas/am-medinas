@echo off
title Control de Desperdicio de Papel - Metrocolor
cd /d "%~dp0"
where py >nul 2>nul && (py -3 servidor.py & goto fin)
where python >nul 2>nul && (python servidor.py & goto fin)
echo No se encontro Python. Instalalo desde https://www.python.org/downloads/
echo (marca la casilla "Add Python to PATH") y vuelve a abrir este archivo.
start https://www.python.org/downloads/
:fin
pause
