/* Conexión de la página con el servidor Python (SQLite).
   Ofrece la misma interfaz que usaba la app (db.collection / db.doc / onSnapshot),
   pero todo se guarda en la base de datos de la PC de la planta. */
(function(){
  const API = '/api';
  const subs = new Set();          // {tipo, ruta, cb, err, ultimo}
  let version = -1, sondeando = false;

  async function pedir(metodo, url, cuerpo){
    const r = await fetch(url, {method:metodo, cache:'no-store',
      headers: cuerpo!==undefined ? {'Content-Type':'application/json'} : {},
      body: cuerpo!==undefined ? JSON.stringify(cuerpo) : undefined});
    let j = null; try{ j = await r.json(); }catch(e){}
    if(!r.ok){ const e = new Error((j&&j.error)||('Error del servidor '+r.status)); e.code='servidor'; throw e; }
    marcarEnLinea(true);
    return j;
  }
  const q = (ruta)=>'?ruta='+encodeURIComponent(ruta);
  const copia = (x)=>x==null ? x : JSON.parse(JSON.stringify(x));

  function snapDoc(ruta, existe, datos){
    return {id: ruta.split('/').pop(), exists: !!existe, data: ()=>copia(datos ?? undefined)};
  }
  function snapCol(docs){
    const d = docs.map(x=>({id:x.id, exists:true, data:()=>copia(x.datos)}));
    return {docs:d, size:d.length, empty:!d.length, forEach:(f)=>d.forEach(f)};
  }
  async function leer(s){
    if(s.tipo==='doc'){ const j = await pedir('GET', API+'/doc'+q(s.ruta)); return {clave: JSON.stringify(j.datos)+'|'+j.existe, snap: snapDoc(s.ruta, j.existe, j.datos)}; }
    const j = await pedir('GET', API+'/coleccion'+q(s.ruta)); return {clave: JSON.stringify(j.docs), snap: snapCol(j.docs)};
  }
  async function refrescar(s, forzar){
    try{
      const {clave, snap} = await leer(s);
      if(!forzar && clave===s.ultimo) return;
      s.ultimo = clave; s.cb(snap);
    }catch(e){ marcarEnLinea(false); if(s.err) s.err(e); }
  }
  async function sondear(){
    if(sondeando) return; sondeando = true;
    try{
      const j = await pedir('GET', API+'/version');
      if(j.v !== version){ version = j.v; await Promise.all([...subs].map(s=>refrescar(s))); }
    }catch(e){ marcarEnLinea(false); }
    sondeando = false;
  }
  setInterval(sondear, 2500);
  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) sondear(); });
  const avisarCambio = ()=>{ version = -1; setTimeout(sondear, 50); };

  function suscribir(tipo, ruta, cb, err){
    const s = {tipo, ruta, cb, err, ultimo:null};
    subs.add(s); refrescar(s, true);
    return ()=>subs.delete(s);
  }
  function docRef(ruta){
    return {
      id: ruta.split('/').pop(), path: ruta,
      get: async()=>{ const j = await pedir('GET', API+'/doc'+q(ruta)); return snapDoc(ruta, j.existe, j.datos); },
      set: async(d)=>{ await pedir('PUT', API+'/doc'+q(ruta), copia(d)); avisarCambio(); },
      update: async(d)=>{ const j = await pedir('GET', API+'/doc'+q(ruta)); await pedir('PUT', API+'/doc'+q(ruta), {...(j.datos||{}), ...copia(d)}); avisarCambio(); },
      delete: async()=>{ await pedir('DELETE', API+'/doc'+q(ruta)); avisarCambio(); },
      onSnapshot: (cb, err)=>suscribir('doc', ruta, cb, err),
      collection: (c)=>colRef(ruta+'/'+c)
    };
  }
  function nuevoIdLocal(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,8); }
  function colRef(ruta){
    const c = {
      path: ruta,
      doc: (id)=>docRef(ruta+'/'+(id || nuevoIdLocal())),
      add: async(d)=>{ const r = docRef(ruta+'/'+nuevoIdLocal()); await r.set(d); return r; },
      get: async()=>{ const j = await pedir('GET', API+'/coleccion'+q(ruta)); return snapCol(j.docs); },
      onSnapshot: (cb, err)=>suscribir('col', ruta, cb, err),
      where: ()=>c, orderBy: ()=>c, limit: ()=>c
    };
    return c;
  }
  const db = Object.freeze({collection: colRef, doc: docRef});

  function idEquipo(){
    try{
      let id = localStorage.getItem('papel_equipo');
      if(!id){ id = 'eq_'+nuevoIdLocal(); localStorage.setItem('papel_equipo', id); }
      return id;
    }catch(e){ return 'eq_temporal'; }
  }
  const esEstaPC = ['localhost','127.0.0.1','::1'].includes(location.hostname);
  const user = Object.freeze({ id: async()=>idEquipo(), isOwner: async()=>esEstaPC, canEdit: async()=>true });

  window.claude = { use: async (nombre)=>{
    if(nombre==='db') return db;
    if(nombre==='user') return user;
    return null;  // descargas, IA: la página usa su alternativa
  }};

  // Contraseñas: en la red local (http) el navegador no trae WebCrypto; el servidor calcula el mismo PBKDF2.
  window.__hashServidor = async (pass, salt)=>(await pedir('POST', API+'/hash', {pass, salt})).hash;

  // Indicador de conexión
  let enLinea = true;
  function marcarEnLinea(v){
    if(v===enLinea) return; enLinea = v;
    const el = document.getElementById('dbStatus');
    if(el) el.textContent = v ? '● Conectado — base de datos de la planta' : '○ Sin conexión con el servidor — revisa que la PC esté encendida';
  }
})();
