# Control de Desperdicio de Papel · Metrocolor (versión Python)

La app ya no depende de Claude: corre en una PC de la planta y guarda todo en
`datos/papel.db` (SQLite). Cada registro se guarda en el momento en que se captura.

## Arrancar
1. Instala Python 3 (python.org, marca **Add Python to PATH**). Solo la primera vez.
2. Doble clic en **INICIAR.bat**.
   La primera vez pide la **clave de datos** (te la dio Claude en el chat). Escríbela y Enter;
   ya no la vuelve a pedir en esa PC. Se abre la app en el navegador.
3. La ventana negra muestra la dirección para celulares y otras PCs de la misma red,
   por ejemplo `http://192.168.1.50:8080`. Déjala abierta mientras se use la app.
   Si Windows pregunta por el Firewall, elige **Permitir** (redes privadas).

## Usuarios
| Usuario | Rol | Contraseña temporal |
|---|---|---|
| armando | administrador | la que te dio Claude |
| adrian | auditor | la que te dio Claude |
| supervisor | supervisor | pendiente: se da de alta en "Darme de alta" |

Cambia las contraseñas temporales con "¿Olvidaste tu contraseña?".

## Respaldos
* Automático: una copia diaria en `datos/respaldos/` (se guardan los últimos 60) y otra al cerrar.
* Manual: abre `http://localhost:8080/api/respaldo` para descargar una copia al momento.
* Para mover la app a otra PC copia la carpeta completa (incluye `datos/`).

## Qué se guarda (todo en la base de datos)
Auditorías, casos RCA, calendario, fallas operativas y guías, usuarios,
desperdicio diario (Excel o pegado), consumo CV y bobinas.

## Notas
* La consulta con IA de Fallas operativas solo funcionaba dentro de Claude; aquí se oculta.
  El resto funciona igual.
* Úsala solo dentro de la red de la planta (no la publiques a Internet).
* Otro puerto: `python servidor.py --puerto 9000`.
